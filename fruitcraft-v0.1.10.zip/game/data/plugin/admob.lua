-- ============================================================
--  Safe no-op stub for the native mobile plugin "admob"
--  (desktop build: the native Android/iOS plugin is not present,
--   so every call is accepted and ignored)
-- ============================================================
local M = {}
setmetatable(M, {
  __index = function(_, k)
    if type(k) == "string" then
      return function() end
    end
    return nil
  end,
  __call = function() end,
})
return M
